(*
#####################################################
#         Diego Russo - diegor.it@gmail.com         #
# Progetto Rilasciato sotto licenza Creative Commons#
# con Attribuzione-Non commerciale 2.5 Italia       #
# http://creativecommons.org/licenses/by-nc/2.5/it/##
#####################################################
*)

(* Modulo contenente funzioni usate per operare sugli LCS *)

open Funzioni_comuni;;

(* Funzione che date due stringhe conta la lunghezza dell'LCS *)
let lunghezza_sottosequenza str1 str2 =
    let i,j = String.length(str1), String.length(str2) (* Prendo la lunghezza delle due stringhe per avere dei limiti massimi *)
      in let rec aux str1 str2 i j =   (* i,j sono le lunghezze delle stringhe *)
            match str1, str2 with
                "",stringa2 -> 0    (* Se la prima stringa è vuola allora la lunghezza dell'LCS è 0 *)
                | stringa1,"" -> 0  (* Se la seconda stringa è vuola allora la lunghezza dell'LCS è 0 *)
                | stringa1,stringa2 -> if i<=0 or j<=0 then 0
                                        else if str1.[i-1] = str2.[j-1] then 1 + aux str1 str2 (i-1) (j-1)
                                            else max (aux str1 str2 (i-1) j) (aux str1 str2 i (j-1))
in aux str1 str2 i j;;

(* Funzione che date due stringhe dice se str1 è lcs di str2 *)
let e_sottosequenza str1 str2 =
    if (lunghezza_sottosequenza str1 str2) = String.length str1 then true else false

(* Funzione che controlla se la stringa passata è LCS delle stringhe presenti in lista *)
let rec lcs_in_lista stringa = function
    [] -> true
    | x::xs ->  e_sottosequenza stringa x && lcs_in_lista stringa xs ;;


