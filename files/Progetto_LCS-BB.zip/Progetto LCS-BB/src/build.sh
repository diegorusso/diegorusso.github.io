#!/bin/bash

#####################################################
#         Diego Russo - diegor.it@gmail.com         #
# Progetto Rilasciato sotto licenza Creative Commons#
# con Attribuzione-Non commerciale 2.5 Italia       #
# http://creativecommons.org/licenses/by-nc/2.5/it/##
#####################################################

#Pulisco tutti i file precompilati precedentemente
rm *.cmi
rm *.cmo
rm lcs-bb

#Compilo ogni singolo modulo
ocamlc -c Funzioni_comuni.ml
ocamlc -c Funzioni_comuni_albero.ml
ocamlc -c Funzioni_comuni_sottosequenza.ml
ocamlc -c Soluzione_con_euristica.ml
ocamlc -c Soluzione_senza_euristica.ml
ocamlc -c Lcs-bb.ml

#Creo l'eseguibile finale con tutte le librerie precedentemente compilate
ocamlc -o lcs-bb Funzioni_comuni.cmo Funzioni_comuni_albero.cmo Funzioni_comuni_sottosequenza.cmo Soluzione_con_euristica.cmo Soluzione_senza_euristica.cmo Lcs-bb.cmo


