(*
#####################################################
#         Diego Russo - diegor.it@gmail.com         #
# Progetto Rilasciato sotto licenza Creative Commons#
# con Attribuzione-Non commerciale 2.5 Italia       #
# http://creativecommons.org/licenses/by-nc/2.5/it/##
#####################################################
*)

(* Modulo contenente tutte le operazioni effettuate in un albero n-ario *)

open Funzioni_comuni;;

(* Funzione di supporto per il calcolo dell'altezza di un albero *)
let rec maxl = function
    [] -> 0
    |[x] -> x  
    | x::xs -> max x (maxl xs);;  

(* Funzione che calcola l'altezza di un albero n-ario *)
let rec altezza (Nodo(x,lista)) =  
    match lista with  
        [] -> 0  
        | _ -> 1 + maxl (List.map altezza lista);;

(* Funzione che verifica se il nodo y è già presente nell'albero con radice (Nodo(x,lista)) *)        
let rec occorre_in (Nodo(x,lista)) y = 
    x=y or occorre_in_lista lista y  
        and occorre_in_lista lista y =
            match lista with  
                [] -> false  
                | t::ts -> occorre_in t y or occorre_in_lista ts y;;
                
(* Funzione che verificando l'esistenza del nodo_figlio nel nodo_padre
    aggiunge il nodo_figlio come figlio del nodo_padre *)
let aggiungi_figlio (nodo_padre, nodo_figlio) = 
    match nodo_padre, nodo_figlio with
        Nodo(x,lista1), Nodo(y,lista2) -> if (occorre_in (Nodo(x,lista1)) y) then
                                            Nodo(x,lista1)
                                          else
                                            Nodo(x,lista1@[Nodo(y,lista2)]);;

(* Funzione che stampa un albero n-ario *)
let stampa_albero t = 
    let rec aux indentazione t =
        match indentazione,t with
             (indentazione,Nodo(x,[])) -> print_string (indentazione^"Foglia(" ^  x ^ ",[])")   (* Stampo una foglia *)
            | (indentazione,Nodo(x,t1::xs)) ->                                                  (* Stampo un nodo con il suo sottoalbero *)
                                        begin
                                            print_string (indentazione^"Nodo(" ^ x ^ ",\n");    (* Stampo il nodo x *)
                                            aux (indentazione^indentazione) t1; print_newline();(* Stampo il figlio t1 ricorsivamente *)
                                            let rec aux2 xs =                                   (* Scorro la lista restante dei figli e la stampo *)
                                                match xs with
                                                    [] -> print_string (indentazione^")")
                                                    | y::ys -> (aux (indentazione^indentazione) y; print_newline();
                                                                aux2 ys; ) 
                                                                in aux2 xs
                                        end
                                    
in aux " " t; print_newline();;

(* Funzione che visita (in postordine) un albero di sottosequenze creando una lista
    con le sottosequenze più lunghe dell'intero dato *)
let rec trova_sottosequenze_albero (Nodo(x,lista)) num = 
	trova_sottosequenze_lista x num lista 
	and trova_sottosequenze_lista x num = function
		[] -> if ((String.length x) > num) then [x] else []
		| t::ts -> (trova_sottosequenze_albero t num) @ (trova_sottosequenze_lista x num ts);;

(* Funzione di supporto per il calcolo della grandezza dell'albero n-ario *)
let rec somma_di = function  
    [] -> 0  
    | x::xs -> x + somma_di xs  

(* Funzione che calcola la grandezza dell'albero con radice (Nodo(_,lista)) *)
let rec numero_nodi (Nodo(_,lista)) =  
    1 + somma_di (List.map numero_nodi lista)