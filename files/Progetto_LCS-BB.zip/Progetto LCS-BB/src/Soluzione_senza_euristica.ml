(*
#####################################################
#         Diego Russo - diegor.it@gmail.com         #
# Progetto Rilasciato sotto licenza Creative Commons#
# con Attribuzione-Non commerciale 2.5 Italia       #
# http://creativecommons.org/licenses/by-nc/2.5/it/##
#####################################################
*)

(* In questo modulo è presente la soluzione senza euristica *)

open Funzioni_comuni;;
open Funzioni_comuni_sottosequenza;;
open Funzioni_comuni_albero;;

(* Questa funzione è il cuore dell'algoritmo e costruisce l'albero.
   L'albero è formato da tutti gli lcs comuni a tutte le stringhe della lista. In questo caso non stimo l'ipotetica
   lunghezza mazzima dell'lcs in questione. *)
let genera_sottosequenze_stringa stringa lst =
        let rec aux lcs stringa posizione lst radice =
            match stringa with
                "" -> radice (* Se la stringa è vuolta ho solo la radice *)
                | str -> if posizione < ((String.length stringa)-1) then (* Se sono ancora nella stringa.. *)
                                let lcs_nuovo = lcs^(carattere_a_stringa stringa.[posizione+1]) in(* Mi calcolo l'lcs in modo induttivo *)
                                        (* verifico che il nuovo lcs sia nella lista *)
                                        if lcs_in_lista lcs_nuovo lst then
                                            let figli = aux lcs_nuovo stringa (posizione+1) lst (Nodo(lcs_nuovo,[])) in (* Definisco i figli di un determinato lcs *)
                                            let fratelli = aggiungi_figlio(radice, figli) in (* Definisco i fratelli di un determinato lcs *)
                                            aux lcs stringa (posizione+1) lst fratelli (* Metto insieme i risultati *)
                                         else
                                            aux lcs stringa (posizione+1) lst radice (* Vado avanti senza creare il nodo *)
                         else
                            radice
in aux "" stringa (-1) lst (Nodo("",[]));;

(*Funzione che data una lista di stringhe, calcola tutti gli lcs della prima stringa e li mette in un albero *)
let genera_sottosequenze_da_lista = function
    [] -> Nodo("",[])
    | x::xs -> genera_sottosequenze_stringa x xs;;
