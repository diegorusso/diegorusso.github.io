(*
#####################################################
#         Diego Russo - diegor.it@gmail.com         #
# Progetto Rilasciato sotto licenza Creative Commons#
# con Attribuzione-Non commerciale 2.5 Italia       #
# http://creativecommons.org/licenses/by-nc/2.5/it/##
#####################################################
*)

(* Questo è il file principale. qui vengono chiesti i vari input da console e lanciate
    le varie elaborazioni delle LCS.
    Questo file inoltre è responsabie della stampa a video dei risultati e dell'albero.*)

(* Importazione dei moduli necessari*)
open Funzioni_comuni;;                  (* Modulo contenente funzionie dichiarazioni comuni *)
open Funzioni_comuni_albero;;           (* Modulo contenente tutte e funzioni riguardanti le operazioni sugli alberi n-ari *)
open Funzioni_comuni_sottosequenza;;    (* Modulo contenente tutte e funzioni riguardanti le operazioni sulle sottosequenze *)
open Soluzione_senza_euristica;;        (* Modulo con la risoluzione dell'algoritmo senza fare uso di un metodo euristico *)
open Soluzione_con_euristica;;          (* Modulo con la risoluzione dell'algoritmo facendo uso di un metodo euristico *)

(* Variabili globali *)
let intero = ref 0;;                    (* Riferimento del valore intero ottenuto dall standard input *)
let albero = ref (Nodo("",[]));;        (* Riferimento all'albero su cui operare *)
let lista_lcs = ref [];;                (* Riferimento alla lista di LCS maggiori dell'intero ottenuto da console *)

(* Funzione principale che chiede all'utente i vari input per l'elaborazione*)
let _ =
    (* Leggo la lista di stringhe da console *)
    print_string "Inserisci le stringhe su cui ricercare l'LCS. Premi invio per andare avanti\n" in
    let lista_stringhe = leggi_stringhe([]) in

    (* Leggo l'intero da console che indica la lunghezza minima dell'LCS*)    
    print_string "Inserisci la lunghezza minima dell'LCS\n";
    intero := read_int();
    
    (* Chiedo al'utente se vuole la soluzione attraverso un metodo euristico *)
    print_string "\nVuoi eseguire la ricerca con un metodo euristico? (si/no)\n";
    let euristica = read_line() in
    if (euristica = "si") then
        (* Chiamo la funzione contenuta nel modulo Soluzione_con_euristica.ml per generarmi l'albero degli LCS*)
        albero := genera_sottosequenze_da_lista_euristica !intero lista_stringhe
    else
        (* Chiamo la funzione contenuta nel modulo Soluzione_senza_euristica.ml per generarmi l'albero degli LCS *)
        albero := genera_sottosequenze_da_lista lista_stringhe;
    
    (* Stampo l'albero appena calcolato *)
    print_string "\nAlbero degli LCS comuni\n";
    stampa_albero !albero;
    
    (* Visito l'albero prendendo solo i nodi che hanno l'LCS maggiore dell'intero *)
    lista_lcs := trova_sottosequenze_albero !albero !intero;
    (* Stampo la lista degli LCS ottenuti *)
    print_string("\nL'elenco degli LCS comuni con lunghezza maggiore di " ^ string_of_int(!intero) ^ ":\n");
    stampa_lista_lcs !lista_lcs;

    (* Calcolo e stampo la grandezza dell'albero *)
    print_string "\nNumero dei nodi dell'albero: ";
    print_string (string_of_int(numero_nodi !albero));
    
    (* Calcolo e stampo il numero di LCS trovati *)
    print_string("\nNumero di LCS trovate maggiori di " ^ string_of_int(!intero) ^ ": ");
    print_string(string_of_int(List.length !lista_lcs)^"\n");;
