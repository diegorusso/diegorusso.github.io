(*
#####################################################
#         Diego Russo - diegor.it@gmail.com         #
# Progetto Rilasciato sotto licenza Creative Commons#
# con Attribuzione-Non commerciale 2.5 Italia       #
# http://creativecommons.org/licenses/by-nc/2.5/it/##
#####################################################
*)

(* In questo modulo è presente la soluzione con un euristica *)

open Funzioni_comuni;;
open Funzioni_comuni_sottosequenza;;
open Funzioni_comuni_albero;;

(* Funzione che data un sottosequenza ed una stringa, calcola l'ultimo carattere della sottosequenza nella stringa *)
let ultima_posizione_carattere lcs stringa = 
    let llcs, lstringa = String.length(lcs), String.length(stringa) in (* calcolo le lunghezze delle stringhe passate *)
        let rec controlla lcs stringa i j = (* i e j sono delle variabili per scorrere le stringhe *)
            match lcs, stringa with
                "",stringa -> (-1)          (* Se l'lcs è vuoto allora ho -1 come ultimo carattere *)
                | stringa, "" -> (-1)       (* Se la stringa è vuota allora ho -1 come ultimo carattere *)
                | lcs,stringa -> if (i = (llcs-1) && lcs.[llcs-1] = stringa.[j]) then j
                                 else if lcs.[i] = stringa.[j] then controlla lcs stringa (i+1) (j+1)
                                        else controlla lcs stringa i (j+1)
in controlla lcs stringa 0 0;;

(* Funzione che dato una sottosequenza ed una stringa stima la lunghezza massima dell'lcs che ha come prefisso la sottosequenza data*)
let max_lunghezza_sottosequenza lcs stringa = 
	let lunghezza_stringa, lunghezza_lcs = String.length(stringa), String.length(lcs) in (* Prendo le relative lunghezze delle stringhe *)
	let ultima_posizione_carattere = ultima_posizione_carattere lcs stringa in (* Calcolo l'ultima posizione del carattere dell'lcs nella stringa *)
	(lunghezza_stringa - ultima_posizione_carattere) + lunghezza_lcs - 1;; (* Stimo la lunghezza massima dell'lcs con prefisso l'lcs passatogli *)


(* Questa funzione è l cuore dell'algoritmo e costruisce l'albero.
   L'albero è formato da tutti gli lcs comuni a tutte le stringhe della lista e con lunghezza stimata più di un intero
   passato da console *)
let genera_sottosequenze_stringa_euristica stringa lst num =
        let rec aux lcs stringa posizione lst radice =
            match stringa with
                "" -> radice (* Se la stringa è vuolta ho solo la radice *)
                | str -> if posizione < ((String.length stringa)-1) then (* Se sono ancora nella stringa.. *)
                                let lcs_nuovo = lcs^(carattere_a_stringa stringa.[posizione+1]) in (* Mi calcolo l'lcs in modo induttivo *)
                                        (* verifico che il nuovo lcs sia nella lista che la stima della sua lunghezza massima sia maggiore di x *)
                                        if ((lcs_in_lista lcs_nuovo lst) && ((max_lunghezza_sottosequenza lcs_nuovo stringa) > num )) then
					    	                let figli = aux lcs_nuovo stringa (posizione+1) lst (Nodo(lcs_nuovo,[])) in (* Definisco i figli di un determinato lcs *)
					       	                let fratelli = aggiungi_figlio(radice, figli) in (* Definisco i fratelli di un determinato lcs *)
	                                      	aux lcs stringa (posizione+1) lst fratelli (* Metto insieme i risultati *)
                                         else
                                        	aux lcs stringa (posizione+1) lst radice (* Vado avanti senza creare il nodo *)
                         else
                            radice
in aux "" stringa (-1) lst (Nodo("",[]));; (* Chiamo la funzione di ausiliaria con tutti i valori iniziali *)

(*Funzione che dato un numero ed una lista di stringhe, calcola tutti gli lcs della prima stringae li mette su un albero *)
let genera_sottosequenze_da_lista_euristica num = function
    [] -> Nodo("",[])
    | x::xs -> genera_sottosequenze_stringa_euristica x xs num;;
