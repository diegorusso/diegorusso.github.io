(*
#####################################################
#         Diego Russo - diegor.it@gmail.com         #
# Progetto Rilasciato sotto licenza Creative Commons#
# con Attribuzione-Non commerciale 2.5 Italia       #
# http://creativecommons.org/licenses/by-nc/2.5/it/##
#####################################################
*)

(* In questo modulo sono contenute le funzioni e dichiarazioni di utilità comune *)

(* Definizione di Nodo di un albero n-ario*)
type 'a nalbero = Nodo of 'a * 'a nalbero list;;                 

(* Definisco la foglia come un nodo ma con la lista dei figli vuota*)                    
let foglia x = Nodo(x,[]);;

(* Converto un carattere da char a string *)
let carattere_a_stringa x = Char.escaped x;; 

(*  Funzione che legge da console una serie di stringhe e ritorna una lista di stringhe
    Si interrompe con una stringa vuota*)
let rec leggi_stringhe (lista) =
      let stringa = read_line()
            in if stringa = "" then lista
               else leggi_stringhe ( stringa::lista );;

(* Funzione che stampa in colonna sullo standard output la lista degli lcs precedentemente calcolati *)
let rec stampa_lista_lcs list =
    match list with
        [] -> print_string("")
        | x::xs -> print_string(x); print_string("\n"); (stampa_lista_lcs xs);;
